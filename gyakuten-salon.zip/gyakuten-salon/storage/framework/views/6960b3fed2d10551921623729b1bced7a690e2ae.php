<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div>
            <h1>投稿の編集</h1>
            
            <form method="post" action="<?php echo e(route('posts.update', ['post'=>$post])); ?>">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                <fieldset class="mb-4">
                    
                    <div class="form-group">
                        <label for="title">タイトル</label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo e($post->title); ?>">
                    </div>
                    
                    <div>
                        <label for="body">本文</label>
                        <textarea id="body" class="form-control" name="body" rows="4" ><?php echo e($post->body); ?>

                        </textarea>
                    </div>
                    
                    <div class="mt-5">
                        <a href="<?php echo e(route('posts.show', ['post'=>$post])); ?>" class="btn btn-secondary">
                            キャンセル
                        </a> 
                        
                        <button type="submit"　class="btn btn-primary">
                            更新する
                        </button>
                    </div>
                    
                </fieldset>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>