<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="mb-4">
            <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary">
                投稿を新規作成する
            </a>
            
        </div>
        
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
        <div class="card mb-4">
            <div class="card-header mb-2"> 
                <?php echo e($post->title); ?>

            </div>
            
            <div class="card-body">
                <p>
                    <?php echo e($post->body); ?>

                </p>
                
                <a class="card-link" href="<?php echo e(route('posts.show', ['post'=>$post])); ?>">
                    詳細を見る
                </a>
            </div>
            
            <div class="card-footer">
                <span>
                    投稿日時
                </span>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>