<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        
        <div class="card mb-4">
            <div class="card-header mb-2"> 
                <?php echo e($post->title); ?>

            </div>
            
            <div class="card-body">
                <p>
                    <?php echo e($post->body); ?>

                </p>
            </div>
            
            <div class="card-footer">
                <span>
                    投稿日時
                </span>
            </div>
        </div>
        
        <div class="mt-4 text-right">
            <a href="<?php echo e(route('posts.edit', ['post'=>$post])); ?>" class="btn btn-primary">
                編集する
            </a>
            
            <form style="display: inline-block" method="post" action="<?php echo e(route('posts.destroy', ['post'=>$post])); ?>"
>
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <button class="btn btn-danger">削除</button>
                
            </form>
                        

            
        </div>
            
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>